#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>       
#include "functions.h"
char *file_path(char *filepath){
	int nb=0;char *lus;
	
	char *tmp=strdup(split(filepath,2));
	char *tmp2=strdup(split(filepath,2));
	lus=strtok(tmp,"/");
	if(lus==NULL){
		nb=0;
	}
	else{
		nb++;
		while(strtok(NULL,"/")!=NULL){
			nb++;
			}
		}
	if(nb==1){
		return "";
		}
	char *path=malloc(100);
	char *mychaine=strtok(tmp2,"/");
	path=strcat(path,mychaine);
	for(int i=0;i<nb-2;i++){
		path=strcat(path,"/");
		path=strcat(path,strtok(NULL,"/"));
		path=strcat(path,"/");

		}
		return path;
	}


int mymv(char *src,char *dest){
	struct posix_header p;
	int i=0,j,lus;
	struct stat st;
	struct stat *buf = &st;
	stat(dest,buf);
	/*if(unlink(dest)<0){
				perror("unlink error");
				exit(-1);
				}*/
	int fd=open(split(src,1),O_RDWR);
	if(fd==-1){
		perror("le repertoire n'existe pas");
		exit(EXIT_FAILURE);
	}
	while(read(fd,&p,512)>0 && p.name[0]!='\0'){
		i+=512;
		if(cmp(split(src,2),p.name)==0){
			memset(&p.name,'0',100);
			lseek(fd,i-512,SEEK_SET);
			for(int i=0;i<(strlen(dest));i++){
					p.name[i]=dest[i];
					p.name[i+1]='0';
				}
			lseek(fd,i-512,SEEK_SET);
			write(fd,&p.name,strlen(dest));	
			lseek(fd,i-512,SEEK_SET);
			read(fd,&p,512);
			printf("name is %s\n",p.name);
			set_checksum(&p);
			printf("reussi");
			return 0;
			
			}

		}
		printf("no such file");

	}



















int main(int argc,char **argv){
   mymv(argv[1],argv[2]);
	//printf("%s\n",file_path(argv[1]));
	return 0;
	}
