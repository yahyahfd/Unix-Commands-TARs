import java.awt.EventQueue;

public class Launcher {
	public static void main(String[] args) {
		try {
			EventQueue.invokeLater(() -> {
				new ImageEditView();
			});
			System.out.println("Fichier trouvé");
		} catch (Exception e) {
			System.out.println("Fichier non trouvé");
		}
	}
}
