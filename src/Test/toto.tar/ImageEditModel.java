import java.awt.Color;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;

import javax.imageio.ImageIO;
import javax.swing.undo.AbstractUndoableEdit;
import javax.swing.undo.UndoManager;

public class ImageEditModel {
	BufferedImage image;
	UndoManager undoManager = new UndoManager();

	public ImageEditModel(String chemin) throws IOException {
		File f = new File(chemin);
		if (f.exists()) {
			image = ImageIO.read(f);
		} else {
			throw new IOException();
		}
	}

	public BufferedImage getImage() {
		return image;
	}

	public void fillzone(Rectangle z, int[][] pixels) {
		int x = (int) z.getX();
		int y = (int) z.getY();
		int l = (int) z.getWidth();
		int h = (int) z.getHeight();
		for (int i = x; i < x + l; i++) {
			for (int j = y; j < y + h; j++) {
				image.setRGB(i, j, pixels[i - x][j - y]);
			}
		}
	}

	public void clearzone(Rectangle z) {
		Color color = Color.white;
		int srgb = color.getRGB();
		int[][] pixels = new int[(int) z.getWidth()][(int) z.getHeight()];
		for (int[] p : pixels)
			Arrays.fill(p, srgb);
		fillzone(z, pixels);
	}

	public void saveCut(Rectangle z) {
		int x = (int) z.getX();
		int y = (int) z.getY();
		int width = (int) z.getWidth();
		int height = (int) z.getHeight();
		BufferedImage subimage = image.getSubimage(x, y, width, height);
		Coupe c = new Coupe(x, y, subimage);
		c.doit();
		CutEdit ce = new CutEdit(c);
		undoManager.addEdit(ce);

	}

	public class Coupe {
		Rectangle z;
		int[][] pixels;

		public Coupe(int x, int y, BufferedImage bi) {
			int width = bi.getWidth();
			int height = bi.getHeight();
			pixels = new int[width][height];
			z = new Rectangle(x, y, width, height);
			for (int i = 0; i < width; i++) {
				for (int j = 0; j < height; j++) {
					pixels[i][j] = bi.getRGB(i, j);
				}
			}
		}

		void doit() {
			clearzone(z);
		}

		void undo() {
			fillzone(z, pixels);
		}
	}

	public class CutEdit extends AbstractUndoableEdit {
		Coupe c;

		public CutEdit(Coupe cp) {
			c = cp;
		}

		public void undo() {
			c.undo();
		}

		public void redo() {
			c.doit();
		}
	}
}
