import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.File;
import java.io.IOException;

import javax.swing.*;

public class ImageEditView extends JFrame {
	JButton cutButton = new JButton();
	JButton undoButton = new JButton();
	JButton redoButton = new JButton();
	ImagePane imagePane;
	ImageEditModel model;

	public ImageEditView() {

		setTitle("Editeur d'image");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel container = new JPanel(new BorderLayout());
		add(container);
		JMenuBar menubar = new JMenuBar();
		setJMenuBar(menubar);
		setResizable(false);
		cutButton.setEnabled(false);
		cutButton.add(new JLabel("Cut"));
		undoButton.setEnabled(false);
		undoButton.add(new JLabel("Undo"));
		redoButton.setEnabled(false);
		redoButton.add(new JLabel("Redo"));
		JButton importButton = new JButton();
		importButton.add(new JLabel("Import"));
		menubar.add(importButton);
		menubar.add(cutButton);
		menubar.add(undoButton);
		menubar.add(redoButton);
		
		importButton.addActionListener((ActionEvent e) -> {
			final JFileChooser fc = new JFileChooser();
			int result = fc.showOpenDialog(new JFrame());
			if (result == JFileChooser.APPROVE_OPTION) {
				File selectedFile = fc.getSelectedFile();
				System.out.println("Selected file: " + selectedFile.getAbsolutePath());
				try {
					container.removeAll();
					model = new ImageEditModel(selectedFile.getAbsolutePath());
					imagePane = new ImagePane();
					imagePane.paintComponent(model.getImage().getGraphics());
					imagePane.setPreferredSize(
							new Dimension((int) model.getImage().getWidth(), (int) model.getImage().getHeight()));
					container.add(imagePane, BorderLayout.CENTER);
					pack();
					repaint();
				} catch (IOException e1) {
					System.out.println("Fichier non trouvé");
				}
			}

		});
		cutButton.addActionListener((

				ActionEvent e) -> {
			model.saveCut(imagePane.selection.getRectangle());
			imagePane.repaint();
			cutButton.setEnabled(false);
			undoButton.setEnabled(true);
			redoButton.setEnabled(true);
		});
		undoButton.addActionListener((ActionEvent e) -> {
			if (model.undoManager.canUndo()) {
				model.undoManager.undo();
				imagePane.repaint();
			}
		});
		redoButton.addActionListener((ActionEvent e) -> {
			System.out.println(model.undoManager.canRedo());
			model.undoManager.redo();
			imagePane.repaint();
		});

		setVisible(true);
		pack();
	}

	class ImagePane extends JPanel {
		Selection selection = new Selection();

		public ImagePane() {
			this.setPreferredSize(new Dimension((int) model.getImage().getWidth(), (int) model.getImage().getHeight()));
			this.addMouseListener(selection);
			this.addMouseMotionListener(selection);

		}

		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			g.drawImage(model.getImage(), 0, 0, this);
			((Graphics2D) g).setStroke(new java.awt.BasicStroke(3));
			((Graphics2D) g).draw(selection.getRectangle());
		}

		public class Selection extends MouseAdapter implements MouseMotionListener {
			int x1;
			int y1;
			int x2;
			int y2;

			Rectangle getRectangle() {
				int x = Math.min(x1, x2);
				int y = Math.min(y1, y2);
				int width = Math.abs(x1 - x2);
				int height = Math.abs(y1 - y2);
				return new Rectangle(x, y, width, height);
			}
			/*
			 * 
			 * mousePressed qui met à jour les coordonnées du point de départ, puis
			 * désactive le bouton cutButton (utilisez setEnabled) et actualise l’affichage
			 * de ImagePane (utilisez l’instruction repaint();).
			 */

			public void mousePressed(MouseEvent e) {
				// resetting
				x2 = e.getX();
				y2 = e.getY();
				x1 = e.getX();
				y1 = e.getY();
				cutButton.setEnabled(false);
				repaint();

			}
			/*
			 * — mouseDragged qui met à jour les coordonnées du point d’arrivée, active le
			 * bouton cutButton (si jamais le point d’arrivée est différent du point de
			 * départ) et actualise l’affichage de ImagePane.
			 */

			public void mouseDragged(MouseEvent e) {
				x2 = e.getX();
				y2 = e.getY();
				if (x2 != x1 || y2 != y1)
					cutButton.setEnabled(true);
				repaint();
			}

			public void mouseMoved(MouseEvent e) {
				// Ne fait rien
			}
		}
	}
}
